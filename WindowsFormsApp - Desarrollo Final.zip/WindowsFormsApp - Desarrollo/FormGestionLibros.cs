﻿using SistemaDeReservasBiblioteca.Controladores;
using SistemaDeReservasBiblioteca.Modelos;

namespace SistemaDeReservasBiblioteca.Vistas
{
    public partial class FormGestionLibros : Form
    {
        private LibroController libroController = new LibroController();

        public FormGestionLibros()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Libro libro = new Libro
            {
                ISBN = txtISBN.Text,
                Titulo = txtTitulo.Text,
                Autor = txtAutor.Text,
                Editorial = txtEditorial.Text,
                AñoPublicacion = int.Parse(txtAño.Text),
                Genero = txtGenero.Text,
                NumeroCopias = int.Parse(txtCopias.Text)
            };
            libroController.AgregarLibro(libro);
            MessageBox.Show("Libro agregado correctamente");
            dataGridViewLibros.DataSource = libroController.ObtenerLibros();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            string isbn = txtISBN.Text;
            libroController.EliminarLibro(isbn);
            MessageBox.Show("Libro eliminado correctamente");
            dataGridViewLibros.DataSource = libroController.ObtenerLibros();
        }

        private void FormGestionLibros_Load(object sender, EventArgs e)
        {
            dataGridViewLibros.DataSource = libroController.ObtenerLibros();
        }
    }
}
