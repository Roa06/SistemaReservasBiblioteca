﻿using SistemaDeReservasBiblioteca.Controladores;

namespace SistemaDeReservasBiblioteca.Vistas
{
    public partial class FormGestionReservas : Form
    {
        private ReservaController reservaController = new ReservaController();

        public FormGestionReservas()
        {
            InitializeComponent();
        }

        private void FormGestionReservas_Load(object sender, EventArgs e)
        {
            // Aquí cargarías las reservas usando el controlador
        }
    }
}
