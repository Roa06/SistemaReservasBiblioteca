﻿using SistemaDeReservasBiblioteca.Controladores;

namespace SistemaDeReservasBiblioteca.Vistas
{
    public partial class FormGestionUsuarios : Form
    {
        private UsuarioController usuarioController = new UsuarioController();

        public FormGestionUsuarios()
        {
            InitializeComponent();
        }

        private void FormGestionUsuarios_Load(object sender, EventArgs e)
        {
            // Aquí cargarías los datos de los usuarios usando el controlador
        }
    }
}
