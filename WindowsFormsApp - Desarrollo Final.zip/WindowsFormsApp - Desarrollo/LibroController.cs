﻿using SistemaDeReservasBiblioteca.Modelos;
using System.Collections.Generic;

namespace SistemaDeReservasBiblioteca.Controladores
{
    public class LibroController
    {
        private List<Libro> libros = new List<Libro>();

        public void AgregarLibro(Libro libro)
        {
            libros.Add(libro);
            // Lógica para insertar en la base de datos
        }

        public void EditarLibro(Libro libro)
        {
            // Lógica para editar libro
        }

        public void EliminarLibro(string isbn)
        {
            // Lógica para eliminar libro
        }

        public List<Libro> ObtenerLibros()
        {
            // Lógica para obtener lista de libros
            return libros;
        }
    }
}