﻿namespace SistemaDeReservasBiblioteca.Modelos
{
    public class Reserva
    {
        public int ReservaID { get; set; }
        public Usuario Usuario { get; set; }
        public Libro LibroReservado { get; set; }
        public DateTime FechaReserva { get; set; }
        public DateTime FechaRetorno { get; set; }
    }
}