﻿using SistemaDeReservasBiblioteca.Modelos;
using System.Collections.Generic;

namespace SistemaDeReservasBiblioteca.Controladores
{
    public class ReservaController
    {
        public List<Reserva> ObtenerReservas()
        {
            // Aquí se implementaría la lógica para obtener las reservas de la base de datos
            return new List<Reserva>();
        }
    }
}
