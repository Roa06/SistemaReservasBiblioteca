﻿using SistemaDeReservasBiblioteca.Modelos;
using System.Collections.Generic;

namespace SistemaDeReservasBiblioteca.Controladores
{
    public class UsuarioController
    {
        public List<Usuario> ObtenerUsuarios()
        {
            // Aquí se implementaría la lógica para obtener los usuarios de la base de datos
            return new List<Usuario>();
        }
    }
}